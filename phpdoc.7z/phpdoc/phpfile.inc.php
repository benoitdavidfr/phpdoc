<?php
/*PhpDoc:
name:  phpfile.inc.php
title: phpfile.inc.php - définition des classes PhpFile, FunClassVar, Method, Parameter et Type
classes:
journal: |
  26-27/11/2016:
    première version
*/
/*PhpDoc: classes
name:  class PhpFile
title: class PhpFile extends File - classe correspondant aux fichiers Php et fichiers inclus .inc.php
doc: |
*/
class PhpFile extends File {
  static $structure = [
    'properties'=>[
      'name' => 'string',
      'title' => 'string',
      'lastUpdate' => 'string',
      'doc' => 'text',
      'journal' => 'text',
    ],
    'childCategories'=>[ // liste des catégories d'enfants avec la classe Php associée
      'screens'=>'Screen',
      'functions'=>'FunClassVar',
      'classes'=>'FunClassVar',
      'variables'=>'FunClassVar',
      'tables'=>'SqlTable', // La table SQL est créée par un script Php
    ],
    'links'=>[
      'includes',// fichiers Php inclus
      'uses',    // utilisation d'une fonction, d'une classe, d'une méthode ou d'une variable
      'hrefs',   // hrefs définis dans le Html de sortie
      'selects', // tables consultées
      'updates', // tables mises à jour
    ],
  ];
};

/*PhpDoc: classes
name:  class FunClassVar
title: class FunClassVar extends InFile - classe correspondant aux functions, aux classes et aux variables
*/
class FunClassVar extends InFile {
  static $structure = [
    'properties'=>[
      'name' => 'string',
      'title' => 'string',
      'resultType' => 'Type', // le type du résultat d'une fonction
      'type' => 'Type',       // Le type d'une variable
      'lastUpdate' => 'string',
      'doc' => 'text',
      'journal' => 'text',
    ],
    'childCategories'=>[ // liste des catégories d'enfants avec la classe Php associée
      'methods'=>'Method', // Les méthodes d'une classe
      'parameters'=>'Parameter', // Les paramètres d'une fonction
      'pubproperties'=>'FunClassVar', // Les propriéts publiques d'une classe
    ],
    'links'=>[
      'uses',  // Une fonction ou une classe peut réutiliser une fonction, une classe ou une méthode
      'selects', // consulte une table
      'updates', // met à jour une table
    ],
  ];
};

/*PhpDoc: classes
name:  class Method
title: class Method extends InFile - classe correspondant aux méthodes
*/
class Method extends InFile {
  static $structure = [
    'properties'=>[
      'name' => 'string',
      'title' => 'string',
      'resultType' => 'Type', // le type du résultat d'une méthode
      'doc' => 'text',
      'journal' => 'text',
    ],
    'childCategories'=>[ // liste des catégories d'enfants avec la classe Php associée
      'parameters'=>'Parameter', // Les paramètres d'une méthode
    ],
    'links'=>[
      'uses',  // Une méthode peut en réutiliser une fonction, une classe ou une autre méthode
      'selects', // consulte une table
      'updates', // met à jour une table
    ],
  ];
};

/*PhpDoc: classes
name:  class Parameter
title: class Parameter extends InFile - classe correspondant aux paramètres d'une fonction ou d'une méthode
*/
class Parameter extends InFile {
  static $structure = [
    'properties'=>[
      'name' => 'string',
      'title' => 'string',
      'type' => 'Type',
      'doc' => 'text',
      'journal' => 'text',
    ],
  ];
};

/*PhpDoc: classes
name:  class Type
title: class Type - définition d'un type
methods:
doc: La classe Type n'appartient pas à la hiérarchie des autres types car les types sont des propriétés et non des enfants
*/
class Type {
  protected $def; // définition du type sous la forme d'une valeur Php
  
/*PhpDoc: methods
name:  __construct
title: function __construct($param) - création d'un type
*/
  function __construct($param) {
    if (isset($_GET['debug']) and $_GET['debug']) {
      $eltType = get_class($this);
      echo "Appel de $eltType::__construct() avec param=<pre>"; var_dump($param); echo "</pre>\n";
    }
    $this->def = $param;
  }
  
/*PhpDoc: methods
name:  toString
title: function toString($def, $level=0) - affichage du type
*/
  function toString($def, $level=0) {
    if (!is_array($def))
      return $def;
    $keys = array_keys($def);
    if ($keys[0]===0)
      return '['.$this->toString($def[0], $level+1).']';
    $result = '';
    $sep = (count($keys)>1 ? "'" : '"');
    foreach ($def as $key=>$value)
      $result .= (!$result?"[\n":",\n").str_repeat('  ',$level+1).$sep.$key.$sep.'=>'.$this->toString($value, $level+1);
    return $result."\n".str_repeat('  ',$level)."]";
  }
  
/*PhpDoc: methods
name:  __toString
title: function __toString() - affichage du type, appele toString()
*/
  function __toString() { return '<pre>'.$this->toString($this->def).'</pre>'; }
};

